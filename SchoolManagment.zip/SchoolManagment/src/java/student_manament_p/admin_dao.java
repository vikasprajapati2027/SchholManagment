/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package student_manament_p;

/**
 *
 * @author Vikas
 */

import java.sql.*;
public class admin_dao {
    Connection con=null;
public Connection getConnection() throws Exception
    {
    Class.forName("com.mysql.jdbc.Driver");
    Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/schoolmanagment","root","");
 return conn;

    }
public int checkuser(String... data) throws Exception
    {
    int i=0;
    con=getConnection();
    Statement stmt=con.createStatement();
    ResultSet rs=stmt.executeQuery("select count(*) from  where admin admin_name='"+data[0]+"' and admin_password='"+data[1]+"'");
    rs.next();
    i=rs.getInt(1);
    return i;
    }
}

