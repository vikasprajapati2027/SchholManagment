/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package student_manament_p;

/**
 *
 * @author Vikas
 */
public class student_registration_pojo {
    int s_id;
    String sname,sfather,smother,semail,mobile_no,saddress,scity,sstates,scountry;

    public int getS_id() {
        return s_id;
    }

    public void setS_id(int s_id) {
        this.s_id = s_id;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getSfather() {
        return sfather;
    }

    public void setSfather(String sfather) {
        this.sfather = sfather;
    }

    public String getSmother() {
        return smother;
    }

    public void setSmother(String smother) {
        this.smother = smother;
    }

    public String getSemail() {
        return semail;
    }

    public void setSemail(String semail) {
        this.semail = semail;
    }

    public String getMobile_no() {
        return mobile_no;
    }

    public void setMobile_no(String mobile_no) {
        this.mobile_no = mobile_no;
    }

    public String getSaddress() {
        return saddress;
    }

    public void setSaddress(String saddress) {
        this.saddress = saddress;
    }

    public String getScity() {
        return scity;
    }

    public void setScity(String scity) {
        this.scity = scity;
    }

    public String getSstates() {
        return sstates;
    }

    public void setSstates(String sstates) {
        this.sstates = sstates;
    }

    public String getScountry() {
        return scountry;
    }

    public void setScountry(String scountry) {
        this.scountry = scountry;
    }

   
}
