/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package student_manament_p;

/**
 *
 * @author Vikas
 */
import java.sql.*;
import java.util.ArrayList;
public class student_managment_Dao {
     Connection con;
    public Connection getConnection()throws Exception
    {
        Class.forName("com.mysql.jdbc.Driver");
        Connection connect=DriverManager.getConnection("jdbc:mysql://localhost:3306/schoolmanagment","root","");
        
        return connect;
    }
    
    public ArrayList<student_registration_pojo>Fetch() throws Exception
    {
        con=getConnection();
        ArrayList<student_registration_pojo> data=new ArrayList<student_registration_pojo>();
        Statement stmt=con.createStatement();
        ResultSet rs=stmt.executeQuery("select * from student_registration");
        while(rs.next())
        {
            student_registration_pojo obj=new student_registration_pojo();
            obj.setS_id(rs.getInt(1));
            obj.setSname(rs.getString(2));
            obj.setSfather(rs.getString(3));
            obj.setSmother(rs.getString(4));
            obj.setSemail(rs.getString(5));
            obj.setMobile_no(rs.getString(6));
            obj.setSaddress(rs.getString(7));
            obj.setScity(rs.getString(8));
            obj.setSstates(rs.getString(9));
            obj.setScountry(rs.getString(10));
            data.add(obj);
          }
          return data;
    }
     public  ArrayList<student_registration_pojo>getdata(int s_id)throws Exception
    {
        con=getConnection();
        ArrayList<student_registration_pojo> data=new ArrayList<student_registration_pojo>();
        Statement stmt=con.createStatement();
        ResultSet rs=stmt.executeQuery("select * from student_registration where s_id='"+s_id+"'");
        rs.next();
        
            student_registration_pojo obj=new student_registration_pojo();
            obj.setS_id(rs.getInt(1));
            obj.setSname(rs.getString(2));
            obj.setSfather(rs.getString(3));
            obj.setSmother(rs.getString(4));
            obj.setSemail(rs.getString(5));
            obj.setMobile_no(rs.getString(6));
            obj.setSaddress(rs.getString(7));
            obj.setScity(rs.getString(8));
            obj.setSstates(rs.getString(9));
            obj.setScountry(rs.getString(10));
            data.add(obj);
          
          return data;
    }
    public int update(int s_id,String sname,String sfather,String smother,String semail,String mobile_no,String saddress,String scity,String sstates,String scountry)throws Exception
    {
        
        con=getConnection();
       Statement stmt=con.createStatement();
      int  j=stmt.executeUpdate("Update student_registration set  sname='"+sname+"' ,sfather='"+sfather+"',smother='"+smother+"' ,semail='"+semail+"',mobile_no='"+mobile_no+"',saddress='"+saddress+"' ,scity='"+scity+"',sstates='"+sstates+"',scountry='"+scountry+"' where s_id='"+s_id+"' ");
       return j;
    }
    public int Insert(String sname,String sfather,String smother,String semail,String mobile_no,String saddress,String scity,String sstates,String scountry)throws Exception
    {
        
        con=getConnection();
        Statement stmt=con.createStatement();
        int kk=stmt.executeUpdate("insert into student_registration(sname,sfather,smother,semail,mobile_no,saddress,scity,sstates,scountry) values('"+sname+"','"+sfather+"','"+smother+"','"+semail+"','"+mobile_no+"','"+saddress+"','"+scity+"','"+sstates+"','"+scountry+"')");
       return kk;
    }
    
    //fees receive amount
    
    
    
    
    
    
    
    public  ArrayList<fees_pojo>Fetchfess() throws Exception
    {
        con=getConnection();
        ArrayList<fees_pojo> data=new ArrayList<fees_pojo>();
        Statement stmt=con.createStatement();
        ResultSet rs=stmt.executeQuery("select * from s_fees");
        while(rs.next())
        {
            fees_pojo obj=new fees_pojo();
            obj.setF_id(rs.getInt(1));
            obj.setFname(rs.getString(2));
            obj.setFroll(rs.getInt(3));
            obj.setFmonth(rs.getString(4));
            obj.setFamount(rs.getInt(5));
            obj.setReceive_date(rs.getString(6));
            data.add(obj);
          }
          return data;
    }
    
     public  ArrayList<fees_pojo>getdatafees(int f_id) throws Exception
    {
        con=getConnection();
        ArrayList<fees_pojo> data=new ArrayList<fees_pojo>();
        Statement stmt=con.createStatement();
        ResultSet rs=stmt.executeQuery("select * from s_fees where f_id='"+f_id+"'");
        rs.next();
        
            fees_pojo obj=new fees_pojo();
            obj.setF_id(rs.getInt(1));
            obj.setFname(rs.getString(2));
            obj.setFroll(rs.getInt(3));
            obj.setFmonth(rs.getString(4));
            obj.setFamount(rs.getInt(5));
            obj.setReceive_date(rs.getString(6));
            data.add(obj);
          
          return data;
    }
        public int updatefees(int f_id,String fname,int froll,String fmonth,int famount,String receive_date)throws Exception
    {
        
        con=getConnection();
       Statement stmt=con.createStatement();
      int  j=stmt.executeUpdate("Update s_fees set  fname='"+fname+"' ,froll='"+froll+"',fmonth='"+fmonth+"' ,famount='"+famount+"',receive_date='"+receive_date+"' where f_id='"+f_id+"' ");
       return j;
    }
    public int Insertfees(String fname,int froll,String fmonth,int famount,String receive_date)throws Exception
    {
        
        con=getConnection();
        Statement stmt=con.createStatement();
        int kk=stmt.executeUpdate("insert into s_fees(fname,froll,fmonth,famount,receive_date) values('"+fname+"','"+froll+"','"+fmonth+"','"+famount+"','"+receive_date+"')");
       return kk;
    }
    
    
    
    
    
    //attendence timing 
    
    
    
        public  ArrayList<attendence_pojo>Fetchattendence() throws Exception
    {
        con=getConnection();
       ArrayList<attendence_pojo> data=new ArrayList<attendence_pojo>();
        Statement stmt=con.createStatement();
        ResultSet rs=stmt.executeQuery("select * from s_attendence");
        while(rs.next())
        {
           attendence_pojo obj=new attendence_pojo();
            obj.setA_id(rs.getInt(1));
            obj.setAname(rs.getString(2));
            obj.setAroll(rs.getInt(3));
            obj.setAdate(rs.getString(4));
            obj.setIn_time(rs.getString(5));
            obj.setOut_time(rs.getString(6));
            data.add(obj);
          }
          return data;
    }
    
     public  ArrayList<attendence_pojo>getdataattendence(int a_id) throws Exception
    {
        con=getConnection();
        ArrayList<attendence_pojo> data=new ArrayList<attendence_pojo>();
        Statement stmt=con.createStatement();
        ResultSet rs=stmt.executeQuery("select * from s_attendence where a_id='"+a_id+"'");
        rs.next();
        
           attendence_pojo obj=new attendence_pojo();
            obj.setA_id(rs.getInt(1));
            obj.setAname(rs.getString(2));
            obj.setAroll(rs.getInt(3));
            obj.setAdate(rs.getString(4));
            obj.setIn_time(rs.getString(5));
            obj.setOut_time(rs.getString(6));
            data.add(obj);
          
          return data;
    }
        public int updateattendence(int a_id,String aname,int aroll,String adate,String in_time,String out_time)throws Exception
    {
        
        con=getConnection();
       Statement stmt=con.createStatement();
      int  j=stmt.executeUpdate("Update s_attendence set  aname='"+aname+"' ,aroll='"+aroll+"',adate='"+adate+"' ,in_time='"+in_time+"',out_time='"+out_time+"' where a_id='"+a_id+"' ");
       return j;
    }
    public int Insertattendence(String aname,int aroll,String adate,String in_time,String out_time)throws Exception
    {
        
        con=getConnection();
        Statement stmt=con.createStatement();
        int kk=stmt.executeUpdate("insert into s_attendence(aname,aroll,adate,in_time,out_time) values('"+aname+"','"+aroll+"','"+adate+"','"+in_time+"','"+out_time  +"')");
       return kk;
    }
    
}
